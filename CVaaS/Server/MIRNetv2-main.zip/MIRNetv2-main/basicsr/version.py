# GENERATED VERSION FILE
# TIME: Thu Apr 14 13:00:18 2022
__version__ = '1.2.0+HEAD'
short_version = '1.2.0'
version_info = (1, 2, 0)
